#ifndef __SWM_RGB_LCD_H__
#define __SWM_RGB_LCD_H__
#include "SWM341.h"

extern uint16_t *LCD_Buffer;

void RGBLCDInit(void);
#endif //__SWM_RGB_LCD_H__
