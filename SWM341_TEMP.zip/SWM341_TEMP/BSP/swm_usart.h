#ifndef __SWM_USART_H__
#define __SWM_USART_H__

void SerialInit(void);

#endif //__SWM_USART_H__
