#ifndef __SWM_DMA2D_H__
#define __SWM_DMA2D_H__

#include "main.h"

extern int a;
void swm_dma2d_init(void);
void dma2d_test_show(char *img_buf);

#endif //__SWM_DMA2D_H__
