# 华芯微特_SWM341系列单片机工程模板

## 模板基础功能

+ PA5灯光闪烁

+ 通过串口PM1(Tx),PM0(Rx)串口打印" Hello, DeepCool! "